import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:provider/provider.dart';
import 'package:red_coprative/view/dashboard/homescreen/cart/add_to_cart.dart';
// ignore: unused_import
import 'package:red_coprative/view/dashboard/homescreen/homescreen.dart';
// ignore: unused_import
import 'package:red_coprative/view/auth/login.dart';
import 'package:red_coprative/view/dashboard/support/cash_withdraw.dart';
import 'view/dashboard/support/add_to_cart.dart';
import 'view/dashboard/dashboard.dart';

import 'view/splash/logoscreen.dart';
import 'data/services/cart_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => CartProvider()), // Initialize CartProvider here
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color.fromARGB(255, 61, 25, 124)),
        useMaterial3: true,
      ),
      home: const Logoscreen(), // You can keep the logo screen here
      routes: {
        '/dashboard': (context) => const Dashboardscreen(), // Navigate to Dashboard first
        
        '/cart': (context) => const AddToCart(),
         
      },
    );
  }
}